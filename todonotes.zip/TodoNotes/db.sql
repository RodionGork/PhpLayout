drop table if exists todo_users;
create table todo_users (
    id int primary key auto_increment,
    username varchar(32),
    password varchar(32));

drop table if exists todo_roles;
create table todo_roles (
    id int primary key auto_increment,
    userid int,
    role varchar(8));

drop table if exists todo_tasks;
create table todo_tasks (
    id int primary key auto_increment,
    title varchar(64),
    authorid int,
    created timestamp default current_timestamp,
    open bool default true);

drop table if exists todo_notes;
create table todo_notes (
    id int primary key auto_increment,
    note text,
    taskid int,
    authorid int,
    created timestamp default current_timestamp
);

drop table if exists todo_links;
create table todo_links (
    id int primary key auto_increment,
    parentid int,
    childid int
);

drop view if exists todo_tasks_view;
create view todo_tasks_view (id, title, created, open, author) as
    select t.id, t.title, t.created, t.open, u.username
        from todo_tasks t join todo_users u on t.authorid = u.id;

drop view if exists todo_notes_view;
create view todo_notes_view (id, note, taskid, created, author) as
    select n.id, n.note, n.taskid, n.created, u.username
        from todo_notes n join todo_users u on n.authorid = u.id;

drop view if exists todo_linksp_view;
create view todo_linksp_view (id, parentid, childid, title) as
    select lnk.id, lnk.parentid, lnk.childid, t.title
        from todo_links lnk join todo_tasks t on lnk.parentid = t.id;

drop view if exists todo_linksc_view;
create view todo_linksc_view (id, parentid, childid, title) as
    select lnk.id, lnk.parentid, lnk.childid, t.title
        from todo_links lnk join todo_tasks t on lnk.childid = t.id;

insert into todo_users values (1, 'odmin', '123456');
insert into todo_roles (userid, role) values (1, 'admin');
insert into todo_roles (userid, role) values (1, 'user');

