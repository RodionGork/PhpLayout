
$(function() {

    function addCommon(whom) {
        var id = prompt('Task # for ' + whom);
        
        if (id == null) {
            return false;
        }
        
        var form = $("#links-form");
        form.find("input[name=" + whom + "]").val(id);
        form.submit();
    }
    
    function addParent() {
        addCommon('parent');
    }

    function addChild() {
        addCommon('child');
    }
    
    $("#link-add-parent").click(addParent);
    $("#link-add-child").click(addChild);
});
