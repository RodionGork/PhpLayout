<h3>Task: <?= $model->task->decodeTitle() ?></h3>

<p>
Author: <?= $model->task->author ?>
<br/>
Created: <?= $model->task->createdTime() ?>
<br/>
<form id="links-form" action="<?= url('task_link') ?>" method="post">
    <input type="hidden" value="<?= $model->task->id ?>" name="taskid"/>
    <input type="hidden" value="" name="parent"/>
    <input type="hidden" value="" name="child"/>
</form>
<?php
if ($model->task->open) {
    echo "<a href=\"" . url('task_close', 'id', $model->task->id) . "\">Close</a>";
} else {
    echo "Closed";
}
?>
</p>

<p>
Parent (blocked) tasks:
<?php foreach ($model->plinks as $lnk) { echo " {$lnk->lnk}"; } ?>

(<a href="#" id="link-add-parent">add</a>)
<br/>
Child (dependent) tasks:
<?php foreach ($model->clinks as $lnk) { echo " {$lnk->lnk}"; } ?>

(<a href="#" id="link-add-child">add</a>)
</p>

<?php
foreach ($model->notes as $note) {
    echo "<hr/><p>Comment {$note->id} by {$note->author} ({$note->created})</p>";
    echo "<pre>{$note->note}</pre>";
}
?>

<?php
if ($ctx->auth->check('user')) :
?>
<hr/>

<div>
Add comment:
<form action="<?= url('task_addnote') ?>" method="post">
<input type="hidden" name="taskid" value="<?= $model->task->id ?>"/>
<textarea name="note"></textarea>
<br/>
<input type="submit" value="Submit"/>
</form>
<?php
endif
?>

