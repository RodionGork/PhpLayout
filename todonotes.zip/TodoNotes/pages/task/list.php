<h3>Tasks</h3>

<?php
if ($ctx->auth->check('user')) :
?>
<div>
<form action="<?= url('task_add') ?>" method="post">
<label>Title:</label>
<input type="text" name="title"/>
<input type="submit" value="New Task"/>
</form>
</div>
<?php
endif
?>

<p>
<b>Showing <?= $model->open ? 'open' : 'closed' ?> tasks</b>
(view <a href="<?= url('task_list', 'state', ($model->open ? 0 : 1)) ?>">others</a>)
</p>

<table class="nice-table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>Author</th>
            <th>State</th>
       </tr>
   </thead>
   <tbody>
<?php
for ($i = 0; $i < sizeof($model->tasks); $i++) {
    $t = $model->tasks[$i];
    echo "<tr><td>{$t->id}</td><td><a href=\"{$t->url}\">" . $t->decodeTitle() . "</td>";
    echo "<td>{$t->author}</td><td>" . $t->statusLabel() . "</td></tr>";
}
?>
    </tbody>
</table>

<br/>
