<h3>Users</h3>

<div>
<form action="<?=url('user_add')?>" method="post">
<label>Username:</label>
<input type="text" name="username"/>
<label>Password:</label>
<input type="text" name="password"/>
<input type="submit" value="Add"/>
</form>
</div>

<table>
    <tr>
        <th>Id</th>
        <th>Username</th>
        <th>Password</th>
   </tr>
<?php
for ($i = 0; $i < sizeof($model->users); $i++) {
    $u = $model->users[$i];
    echo "<tr><td>{$u->id}</td><td>{$u->username}</td><td>{$u->password}</td></tr>";
}
?>
</table>

