<h3>Warning</h3>

<p><b>Result: <?= $model->msg ?></b></p>

<p>Press 'back' button to return to previous page</p>
