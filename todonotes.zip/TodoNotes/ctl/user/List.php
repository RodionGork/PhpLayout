<?php

if ($ctx->auth->checkWith404('admin') === false) {
    return;
}

$model->users = $ctx->usersDao->find();

?>
