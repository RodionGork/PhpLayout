<?php

if ($ctx->auth->checkWith404('admin') === false) {
    return;
}

$ctx->elems->page = 'warning';

$u = new stdClass();
$u->username = $ctx->util->paramPost('username');
$u->password = $ctx->util->paramPost('password');

if (!$u->username || !$u->password) {
    $model->msg = 'No sufficient data for adding user';
    return;
}

$exists = $ctx->usersDao->findFirst("username = '{$u->username}'");

if ($exists !== false) {
    $model->msg = "Username already exists";
    return;
}

$id = $ctx->usersDao->save($u);

$r = new stdClass();
$r->userid = $id;
$r->role = 'user';

$ctx->rolesDao->save($r);

$ctx->util->redirect(url('user_list'));

?>
