<?php

$ctx->auth->logout();

$ctx->util->redirect(url('main'));

?>
