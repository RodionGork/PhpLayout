<?php

function dateReformat($s) {
    return date('j M Y - H:i:s', strtotime($s));
}

$id = $_GET['id'];

$model->task = $ctx->tasksViewDao->findFirst("id = $id");

$notes = $ctx->notesViewDao->find("taskid = $id");

$taskUrl = url('task_view', 'id', '');

foreach ($notes as $note) {
    $note->created = dateReformat($note->created);
    $note->note = htmlentities(base64_decode($note->note));
    $note->note = preg_replace('/#(\d+)/', "<a href=\"$taskUrl$1\">#$1</a>", $note->note);
}

$model->notes = $notes;

$plinks = $ctx->linksPViewDao->find("childid = $id");

foreach ($plinks as $lnk) {
    $url = $taskUrl . $lnk->parentid;
    $lnk->title = htmlentities(base64_decode($lnk->title));
    $lnk->lnk = " <a href=\"{$url}\" title=\"{$lnk->title}\">{$lnk->parentid}</a>";
}

$clinks = $ctx->linksCViewDao->find("parentid = $id");

foreach ($clinks as $lnk) {
    $url = $taskUrl . $lnk->childid;
    $lnk->title = htmlentities(base64_decode($lnk->title));
    $lnk->lnk = " <a href=\"{$url}\" title=\"{$lnk->title}\">{$lnk->childid}</a>";
}

$model->plinks = $plinks;
$model->clinks = $clinks;

?>

