<?php

if ($ctx->auth->checkWith404('user') === false) {
    return;
}

$ctx->elems->page = 'warning';

$taskid = $ctx->util->paramGet('id');

if (!$taskid) {
    $model->msg = 'Task number should be specified!';
    return;
}

$task = $ctx->tasksDao->findFirst("id = $taskid");

if (!$task) {
    $model->msg = "Task #$taskid not found";
    return;
}

$task->open = false;
$ctx->tasksDao->save($task);

$ctx->util->redirect(url('task_view', 'id', $taskid));

?>

