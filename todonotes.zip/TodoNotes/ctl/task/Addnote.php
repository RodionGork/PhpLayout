<?php

if ($ctx->auth->checkWith404('user') === false) {
    return;
}

$ctx->elems->page = 'warning';

$taskid = $ctx->util->paramPost('taskid');
$text = $ctx->util->paramPost('note');

if (!$taskid || !$text) {
    $model->msg = 'Insufficient data provided!';
    return;
}

$note = new stdClass();
$note->note = base64_encode($text);
$note->taskid = $taskid;
$note->authorid = $ctx->auth->loggedUser();

$ctx->notesDao->save($note);

$ctx->util->redirect(url('task_view', 'id', $taskid));

?>

