<?php

$state = $ctx->util->paramGet('state');

$model->open = ($state === null || $state == 1);

$tasks = $ctx->tasksViewDao->find('open = ' . ($model->open ? 1 : 0));

foreach ($tasks as $t) {
    $t->url = url('task_view', 'id', $t->id);
}

$model->tasks = $tasks;

?>

