<?php

if ($ctx->auth->checkWith404('user') === false) {
    return;
}

$ctx->elems->page = 'warning';

$title = $ctx->util->paramPost('title');

if (!$title) {
    $model->msg = 'Title should be provided!';
    return;
}

module('entity/Task');

$task = new Task($ctx->auth->loggedUser(), $title);

$ctx->tasksDao->save($task);

$ctx->util->redirect(url('task_list'));

?>

