<?php

if ($ctx->auth->checkWith404('user') === false) {
    return;
}

$ctx->elems->page = 'warning';

$taskid = $ctx->util->paramPost('taskid');
$parent = $ctx->util->paramPost('parent');
$child = $ctx->util->paramPost('child');

if (!$taskid || !($parent || $child)) {
    $model->msg = 'Insufficient data!';
    return;
}

$deleteCond = null;

if ($parent < 0) {
    $parent = -$parent;
    $deleteCond = "parentid = $parent and childid = $taskid";
}
if ($child < 0) {
    $child = -$child;
    $deleteCond = "parentid = $taskid and childid = $child";
}

if ($deleteCond !== null) {
    $lnk = $ctx->linksDao->findFirst($deleteCond);
    if ($lnk === false) {
        $model->msg = 'Link not found!';
        return;
    }
    $ctx->linksDao->delete($lnk->id);
} else {
    $link = new stdClass();
    if ($parent) {
        $link->parentid = $parent;
        $link->childid = $taskid;
    } else {
        $link->parentid = $taskid;
        $link->childid = $child;
    }
    $ctx->linksDao->save($link);
}

$ctx->util->redirect(url('task_view', 'id', $taskid));

?>

