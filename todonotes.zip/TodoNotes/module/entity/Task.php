<?php

class Task {

    function __construct($authorid = null, $title = null) {
        if ($authorid !== null) {
            $this->authorid = $authorid;
            $this->encodeTitle($title);
        }
    }
    
    function encodeTitle($text) {
        $this->title = base64_encode($text);
    }
    
    function decodeTitle() {
        return htmlentities(base64_decode($this->title));
    }
    
    function statusLabel() {
        return $this->open ? 'Open' : 'Closed';
    }
    
    function createdTime() {
        return dateReformat($this->created);
    }

}

?>
