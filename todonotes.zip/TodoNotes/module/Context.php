<?php

module('sys/ProtoContext');

class Context extends ProtoContext {

    protected function getAuth() {
        module('MyAuth');
        return new MyAuth();
    }
    
    protected function getUsersDao() {
        module('dao/MysqlDao');
        return new MysqlDao('users');
    }

    protected function getRolesDao() {
        module('dao/MysqlDao');
        return new MysqlDao('roles');
    }

    protected function getTasksDao() {
        module('dao/MysqlDao');
        module('entity/Task');
        return new MysqlDao('tasks', 'Task');
    }

    protected function getTasksViewDao() {
        module('dao/MysqlDao');
        module('entity/Task');
        return new MysqlDao('tasks_view', 'Task');
    }
    
    protected function getNotesDao() {
        module('dao/MysqlDao');
        return new MysqlDao('notes');
    }

    protected function getNotesViewDao() {
        module('dao/MysqlDao');
        return new MysqlDao('notes_view');
    }
    
    protected function getLinksDao() {
        module('dao/MysqlDao');
        return new MysqlDao('links');
    }
    
    protected function getLinksPViewDao() {
        module('dao/MysqlDao');
        return new MysqlDao('linksp_view');
    }
    
    protected function getLinksCViewDao() {
        module('dao/MysqlDao');
        return new MysqlDao('linksc_view');
    }
    
}

?>
