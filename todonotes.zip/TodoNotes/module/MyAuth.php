<?php

module('dao/MysqlDao');
module('auth/DaoAuth');

$moduleDefinition = array('name' => 'MyAuth');

class MyAuth extends DaoAuth {

    function MyAuth() {
        parent::__construct(new MysqlDao('users'), new MysqlDao('roles'));
    }
    
}
?>
